<!DOCTYPE html>
<html lang="zh-HK">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#1a73e8">
<link rel="apple-touch-icon" sizes="192x192" href="/icons/192.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<?php //ob_start('ob_gzhandler'); ?> 
<style>
body {
  font-family: 'Inter', sans-serif;
  margin: 0;
  background-color: #f8fafc;
  padding-bottom: 3rem;
  color: #2d2d2d;
}

/* Navbar */
.navbar {
  background: linear-gradient(90deg, rgba(26,115,232,0.95), rgba(66,133,244,0.95));
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  padding: 0.75rem 1rem;
}

.navbar-brand {
  font-size: 1.5rem;
  font-weight: 700;
  color: #fff;
  letter-spacing: 0.5px;
}
.navbar-nav .nav-link {
  font-size: 1.05rem;
  font-weight: 500;
  color: #e9efff;
  padding: 0.8rem 1.3rem;
  border-radius: 8px;
  transition: background-color 0.2s ease, transform 0.2s ease;
}
.navbar-nav .nav-link:hover {
  background-color: rgba(255,255,255,0.15);
  color: #fff;
  transform: scale(1.02);
}
.navbar-nav .nav-link.active {
  background-color: rgba(255,255,255,0.25);
  color: #fff;
}
.navbar-toggler {
  border: none;
  padding: 0.5rem;
}
.navbar-toggler:focus {
  box-shadow: none;
}
.navbar-toggler-icon {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba(255,255,255,0.9)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
}

/* Mobile overlay menu */
@media (max-width: 991.98px) {
  .navbar-collapse {
    position: fixed;
    top: 60px;
    left: 0;
    width: 100%;
    height: calc(100% - 60px);
    background: #1a73e8;
    padding: 1.5rem;
    overflow-y: auto;
    z-index: 1050;
    transform: translateY(-100%);
    transition: transform 0.3s ease-in-out;
  }
  .navbar-collapse.show {
    transform: translateY(0);
  }
  .navbar-nav .nav-link {
    color: #fff;
    font-size: 1.15rem;
    margin: 0.6rem 0;
    padding: 0.8rem 1rem;
  }
  .navbar-nav .nav-link.active {
    background-color: rgba(255,255,255,0.25);
  }
}
@media (min-width: 992px) {
  .navbar-collapse {
    position: static !important;
    transform: none !important;
    height: auto;
    background: transparent;
    padding: 0;
  }
}

/* Loader */
#loader {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255,255,255,0.96);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  flex-direction: column;
  transition: opacity 0.3s ease-out;
}
.spinner {
  width: 48px;
  height: 48px;
  border: 5px solid transparent;
  border-top-color: #ff6f61;
  border-right-color: #6bc4e8;
  border-bottom-color: #feca57;
  border-left-color: #ff9ff3;
  border-radius: 50%;
  animation: spin 1s ease-in-out infinite, pulse 1.5s ease-in-out infinite;
  margin-bottom: 1.2rem;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.1); }
}
.loader-text {
  font-size: 1.05rem;
  font-weight: 500;
  color: #ff6f61;
  letter-spacing: 0.5px;
  animation: fadeInOut 1.5s ease-in-out infinite;
}
@keyframes fadeInOut {
  0%, 100% { opacity: 0.6; }
  50% { opacity: 1; }
}

/* Error message */
#error-message {
  display: none;
  text-align: center;
  color: #ff6f61;
  font-size: 1rem;
  font-weight: 500;
  margin: 1rem;
  padding: 0.75rem;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}

/* Container */
.container-fluid {
  max-width: 1400px;
  padding-left: 0;
  padding-right: 0;
}

/* Table */
#table {
  margin: 0;
  overflow-x: auto;
  border-radius: 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  background: #fff;
  will-change: contents;
  transition: opacity 0.1s ease;
  transform: translate3d(0, 0, 0); /* Enable hardware acceleration */
  backface-visibility: hidden; /* Prevent flicker on iOS */
}
#table table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  margin: 0;
}
#table table th, #table table td {
  padding: 1rem;
  border-bottom: 1px solid #d1d5db;
  text-align: center;
  font-size: 1rem;
}
#table table th {
  background: #f1f5f9;
  font-weight: 600;
  color: #2d2d2d;
  font-size: 0.9rem;
  letter-spacing: 0.3px;
}
#table table td {
  color: #374151;
}
#table table tr:hover {
  background-color: #e0f2fe;
  transition: background-color 0.2s ease;
}
#table table tr:last-child td {
  border-bottom: none;
}
#table-buffer {
  position: absolute;
  visibility: hidden;
  pointer-events: none;
}

/* iOS-specific adjustments */
@media only screen and (-webkit-min-device-pixel-ratio: 1) {
  #table table th {
    font-size: 0.85rem;
    padding: 0.8rem;
  }
}

/* Last update */
#lastUpdate {
  font-weight: 500;
  font-size: 0.95rem;
  color: #4b5563;
  text-align: left;
  margin: 1.5rem 0;
  padding-left: 1rem;
}
</style>

<title>輕鐵實時訊息</title>
</head>
<body>

<!-- Loader -->
<div id="loader">
  <div class="spinner"></div>
  <div class="loader-text">輕鐵數據載入中…</div>
</div>

<!-- Error message -->
<div id="error-message">無法載入輕鐵數據，請稍後再試！</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <?php $station = $_GET['name'] ?? "大興(南)"; ?>
    <a class="navbar-brand" href="./">輕鐵 - <span id="station-name"><?php echo $station; ?></span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="geolocation" data-name="使用我的位置">使用我的位置</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="220" data-name="大興(南)">大興(南)</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="100" data-name="兆康">兆康</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="295" data-name="屯門">屯門</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="280" data-name="市中心">市中心</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="270" data-name="安定">安定</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="560" data-name="水邊圍">水邊圍</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="570" data-name="豐年路">豐年路</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="580" data-name="康樂路">康樂路</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="590" data-name="大棠路">大棠路</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="600" data-name="元朗">元朗</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="430" data-name="天水圍">天水圍</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="460" data-name="天瑞">天瑞</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="480" data-name="天富">天富</a></li>
        <li class="nav-item"><a class="nav-link" href="javascript:void(0)" data-id="468" data-name="頌富">頌富</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Table containers -->
<div id="table"></div>
<div id="table-buffer"></div>

<!-- Last update -->
<p id="lastUpdate" class="container-fluid"></p>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// --- LRT stations ---
const lrtStations = [
  { id: '220', name: '大興(南)', lat: 22.40281821611273, lng: 113.97203523032393 },
  { id: '100', name: '兆康', lat: 22.412013954554574, lng: 113.97839328454653 },
  { id: '295', name: '屯門', lat: 22.39405653737988, lng: 113.97288393949789 },
  { id: '280', name: '市中心', lat: 22.391473888531404, lng: 113.97497385511649 },
  { id: '270', name: '安定', lat: 22.387940178705854, lng: 113.97505852639564 },
  { id: '560', name: '水邊圍', lat: 22.444617253662155, lng: 114.01989951173945 },
  { id: '570', name: '豐年路', lat: 22.444738245990856, lng: 114.02376243265216 },
  { id: '580', name: '康樂路', lat: 22.444711482540036, lng: 114.02717108105638 },
  { id: '590', name: '大棠路', lat: 22.44477799854364, lng: 114.02892926571472 },
  { id: '600', name: '元朗', lat: 22.446001529588745, lng: 114.0338110969568 },
  { id: '430', name: '天水圍', lat: 22.44846730647476, lng: 114.00457100528374 },
  { id: '460', name: '天瑞', lat: 22.45622127702453, lng: 113.99952845264237 },
  { id: '480', name: '天富', lat: 22.464647436539735, lng: 113.99765969796667 },
  { id: '468', name: '頌富', lat: 22.462368618188663, lng: 113.99706082055354 }
];

// --- Utilities ---
function getDistance(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function findNearestStation(userLat, userLng) {
  let nearest = lrtStations[0], minDistance = Infinity;
  lrtStations.forEach(station => {
    const distance = getDistance(userLat, userLng, station.lat, station.lng);
    if (distance < minDistance) {
      minDistance = distance;
      nearest = station;
    }
  });
  return nearest;
}

// --- Cache & state ---
let tableCache = { id: null, tableData: null, systemTime: '', timestamp: 0 };
const cacheDuration = 5000;
let lastPosition = null;
let manualSelection = false;

// --- Loader helpers ---
function showLoader(text = "輕鐵數據載入中…") {
  const loader = document.getElementById('loader');
  const loaderText = loader.querySelector('.loader-text');
  loaderText.textContent = text;
  loader.style.display = 'flex';
  loader.style.opacity = '1';
}

function hideLoader() {
  const loader = document.getElementById('loader');
  loader.style.opacity = '0';
  setTimeout(() => loader.style.display = 'none', 300);
}

// --- Fetch last update ---
async function fetchLastUpdate(id) {
  try {
    const response = await fetch(`https://rt.data.gov.hk/v1/transport/mtr/lrt/getSchedule?station_id=${id}&_=${Date.now()}`, { cache: 'no-store' });
    if (!response.ok) throw new Error('API response was not ok');
    const data = await response.json();
    return data.system_time || '';
  } catch (error) {
    console.error('Failed to fetch last update:', error);
    return '';
  }
}

// --- Table update ---
function updateTableRows(oldTbody, newTbody) {
  const oldRows = oldTbody.querySelectorAll('tr');
  const newRows = newTbody.querySelectorAll('tr');
  const maxRows = Math.max(oldRows.length, newRows.length);
  for (let i = 0; i < maxRows; i++) {
    if (i >= oldRows.length) oldTbody.appendChild(newRows[i].cloneNode(true));
    else if (i >= newRows.length) oldRows[i].remove();
    else if (oldRows[i].innerHTML !== newRows[i].innerHTML) oldRows[i].innerHTML = newRows[i].innerHTML;
  }
}

// --- Get URL parameter ---
function getParameterByName(name, url = window.location.href) {
  name = name.replace(/[[\]]/g, "\\$&");
  const regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
  const results = regex.exec(url);
  return results ? decodeURIComponent(results[2]?.replace(/\+/g, " ") || "no") : null;
}

// --- Debounce ---
function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// --- Refresh messages ---
async function refreshMessages(id = null, forceGeo = false) {
  const errorMessage = document.getElementById('error-message');
  const tableContainer = document.getElementById('table');
  const tableBuffer = document.getElementById('table-buffer');
  const lastUpdate = document.getElementById('lastUpdate');
  const stationNameEl = document.getElementById('station-name');
  const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
  const now = Date.now();

  let stationId = id || getParameterByName('id');
  let stationName = getParameterByName('name') || '大興(南)';

  // --- Geo-location ---
  if ((!stationId || forceGeo) && !manualSelection) {
    try {
      showLoader("定位中…");
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 30000 });
      });
      const newPosition = position.coords;
      const nearestStation = findNearestStation(newPosition.latitude, newPosition.longitude);
      stationId = nearestStation.id;
      stationName = nearestStation.name;
      lastPosition = newPosition;
      navLinks.forEach(link => link.classList.remove('active'));
      document.querySelector(`.nav-link[data-id="geolocation"]`).classList.add('active');
      history.replaceState(null, '', `?id=${stationId}&name=${encodeURIComponent(stationName)}`);
      hideLoader();
    } catch (error) {
      console.error('Geolocation failed:', error);
      stationId = '220';
      stationName = '大興(南)';
      navLinks.forEach(link => link.classList.remove('active'));
      document.querySelector(`.nav-link[data-id="220"]`).classList.add('active');
      errorMessage.textContent = '無法獲取位置，使用預設站點：大興(南)';
      errorMessage.style.display = 'block';
      hideLoader();
    }
  }

  // --- Manual selection ---
  if (stationId && manualSelection) {
    const station = lrtStations.find(s => s.id === stationId);
    if (station) {
      stationName = station.name;
      navLinks.forEach(link => link.classList.remove('active'));
      document.querySelector(`.nav-link[data-id="${stationId}"]`).classList.add('active');
    } else {
      stationId = '220';
      stationName = '大興(南)';
      navLinks.forEach(link => link.classList.remove('active'));
      document.querySelector(`.nav-link[data-id="220"]`).classList.add('active');
    }
  }

  stationNameEl.textContent = stationName;

  // --- Check cache ---
  if (tableCache.id === stationId && tableCache.tableData && (now - tableCache.timestamp) < cacheDuration && !forceGeo) {
    requestAnimationFrame(() => {
      tableContainer.innerHTML = tableCache.tableData;
      lastUpdate.textContent = tableCache.systemTime ? "最後更新時間: " + tableCache.systemTime : '';
      hideLoader();
      tableContainer.offsetHeight;
    });
    return;
  }

  try {
    if (!tableContainer.innerHTML || tableCache.id !== stationId) showLoader();

    const tableResponse = await fetch(`table.php?id=${stationId}&_=${now}`, { cache: 'no-store' });
    if (!tableResponse.ok) throw new Error('Table response was not ok');
    const tableData = await tableResponse.text();
    const systemTime = await fetchLastUpdate(stationId);

    requestAnimationFrame(() => {
      tableBuffer.innerHTML = tableData;
      const newTable = tableBuffer.querySelector('table');
      const oldTable = tableContainer.querySelector('table');
      if (newTable && oldTable) updateTableRows(oldTable.querySelector('tbody'), newTable.querySelector('tbody'));
      else {
        tableContainer.style.opacity = '0';
        tableContainer.innerHTML = tableData;
        tableContainer.style.opacity = '1';
      }

      tableCache = { id: stationId, tableData, systemTime: systemTime || '', timestamp: now };
      //lastUpdate.textContent = systemTime ? "最後更新時間: " + systemTime : '';
      hideLoader();
      errorMessage.style.display = 'none';
      tableContainer.offsetHeight;
    });
  } catch (error) {
    console.error('Failed to load table data:', error);
    requestAnimationFrame(() => {
      errorMessage.textContent = '無法載入輕鐵數據，請稍後再試！';
      errorMessage.style.display = 'block';
      if (tableCache.id === stationId && tableCache.tableData) {
        tableContainer.innerHTML = tableCache.tableData;
        lastUpdate.textContent = tableCache.systemTime ? "最後更新時間: " + tableCache.systemTime : '';
      }
      hideLoader();
      tableContainer.offsetHeight;
    });
  }
}

// --- Debounced refresh ---
const debouncedRefresh = debounce((forceGeo) => refreshMessages(null, forceGeo), 500);

// --- Navbar selection ---
document.addEventListener('DOMContentLoaded', () => {
  const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
  const navbarCollapse = document.getElementById('navbarNav');
  const bsCollapse = new bootstrap.Collapse(navbarCollapse, { toggle: false });

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const id = link.getAttribute('data-id');
      const name = link.getAttribute('data-name');
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      if (window.innerWidth < 992) bsCollapse.hide();

      if (id === 'geolocation') {
        manualSelection = false;
        lastPosition = null;
        refreshMessages(null, true);
      } else {
        manualSelection = true;
        history.replaceState(null, '', `?id=${id}&name=${encodeURIComponent(name)}`);
        refreshMessages(id, false);
      }
    });
  });

  // --- Initial load ---
  refreshMessages(null, true);

  // --- Auto refresh ---
  setInterval(() => debouncedRefresh(false), 5000); // table refresh
  setInterval(() => { lastPosition = null; refreshMessages(null, true); }, 180000); // geo every 3 mins
});

// --- Visibility / focus triggers ---
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    lastPosition = null;
    refreshMessages(null, true);
  }
});
window.addEventListener('focus', () => {
  lastPosition = null;
  refreshMessages(null, true);
});

// --- Wake Lock ---
let wakeLock = null;
async function requestWakeLock() {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', () => requestWakeLock());
    } else enableIOSKeepAlive();
  } catch (err) {
    console.error(err.name, err.message);
  }
}

function enableIOSKeepAlive() {
  const video = document.createElement('video');
  video.setAttribute('playsinline','');
  video.setAttribute('muted','');
  video.setAttribute('loop','');
  video.style.position='absolute';
  video.style.width='1px';
  video.style.height='1px';
  video.style.opacity='0';
  video.src = 'data:video/mp4;base64,.AAAAGGZ0eXBtcDQyAAAAAGlzb21tcDQyAAAAAW1kYXQAAAAAAAFi0gAACldluE+8GxamyNZ3gCSH/4SnYtMWWIHpS380X7vtaNP8ZP8tw4qgwh3kWBXN79oeiChF0CkNHEBD6jIaTksAATYgfBO39mP1wfafSx46MDu50jVzE2Z4HxhfLzG2ujTL7TbDcfxsULklmLds+QG+BEdMU1+QWif2UWdGRuTqhUK0EfbZQoBquf7UH8q3Zf79XNj+d2bNFt8Mq8UjX8TM6bvDL/Mi12ymeeKcnp4XOZSbMHVTAyRkZUUXY5FljI8afWsMV5S+YjlBo1R879/4zT6fp7fjQAhmOXX5kNkx7uu0NdtbRFabfvq42ognbOmV5+vjACrpMnLYaDoMM0yBdLYm425KOIm/qxHrKLQV1M6JekyEdhxW17r/Z5SBpQuQ4g0jKW2Z6uSebK32CVDN+GQZLncL77HDRRBap9BpS5cCnhsUs3HjjpxPAvjY82RhyAE7ttwoLInmCBHPjIr41SzqMEW/27Gym0m2HvS7VJwdMT8KS4rU3uGwdWxLTGJI+xfleR6cTecFZWXFOY8a6R8SZxtEphpH9qZ/GT4lrOiyz2jplZ9tlj+LFOICoO/M++eyf5NAgTtaNQVjiHoQshtkTlIHLwMVR+v/XAY5BR+I6aNv8MSGwT6bX1p5vz//8KjrQw8yLO1wedDpPP4sBA34RFX9GwSZDEk8y7+Y9kZv6qkHwpxAlFvX0tg9mld5PL+MazlNsboght8ggVEnTTS6fYPmxR7nVhVpMVUnWemK9V3GQacoOpA8bxJnN+gYA/AiDFcNfN32ySyJntXe51GNi9K2R05Znyp0pnT1wfBGNUbTJCOp76wLpvMULT6c/6HkHB0W7ivsdyNSGaQ/3muO4vq+QKwzUESsLecZhH4wyoVKg4cn/tncK1FTOE1fK+xppWjdgIblrIKKJYQ5h83gNAuvG4QwwcGbK1wJkAdbabAtUSMWA8Il/1gdgJ1lDWG4J+6PnZWXX3mWXNUqA7aSNr6hj0Aj0uQrnfsdg66sy8wibONwKbyaZ2iCt/kaJ8G/J7CudgOkFYB066jPQRpUt59YQKL0ExA1V2inLDs324KGhtd29LoqBeNivMyNCpaaZLGHjmjr+ctjIqUFtWzB/R0x4Ghv5d6BSUIgH/oSIJ4c96krBbKcIf64J2FlOHLKEtFy/iqn2BAYulKsZLABXjgYuBhZ2vhtV6waU4Fx8+AD7jR5Aq1E1Pt0AjuHICyNjb2rMJaeAq7u7b1or8Rfcc0nvXMoetZxggkwDeYV3dbO9xRpDeSq1mK8yXWaAh1WL2ZvlcEdkZm8jAsxIBsFJ40KFInVASx4Ef28YzkgKRgJ/9FJDsTfq+B9bUklG+Y+rGvt8kyPKVIjTxKC84sbIDKi7DHn9668kfA9cyAFGonbKl/bs2SBaYOupIboJcDkZ0JksD2laoIL5heqe6+YkazLBUyI4ZVLxA8p9Oj6Vr+roCNzldAzNefA69XjydUtohd4zLklwTZUrPbqu+J7PfLLHZdAg8NWPTDXKj54yCXWfLLqutj2rhIdnUltSh5/7f6RVudSDCQqjGrzpBhU1qiomSw7hNaGY2DrhqqQDu52EFIr3DbTB44Cn9QRmvc+NOmUfTGU5j3RiNEmsKXAHUSyyUmQyYudae+w3JNhxVKtJjwPkbRufL+4QrU5Go2zibnHShQH1nQmKwlYeZu8BJYcQxrx7TfWPFw1CYdiMxInSAvnXV5hzw6KEpXFA3/vENvFHCRpGGxiJTo6L9Qr+jTbhUjjj1Coxxa/pT7Po3okgVMjfDbA/B/xHGntMDK1fiozAPxrM3pk9KjvsUp8Chme6W82HaGVZFjLv3pvEdberS37EiQGh2AMt0ysWJ+AbSS8L5bLvTrSyX2/+6bFb1kSeAZcWvL8Eyp221clykle9HjrsNRnLh0fKObLyNmbVmkQ5r1WjK54+IgeTY9H1g9D2BoupKOjQzTmI8VYetBk72tagMvLPfhL1PtHPLkODvcBH35v2B4O330VIdrj4CZZo7ebcYCpzFYRiwFKX5dCyoZ1C1QPcZnb609CF9NppPQexKajZgBgSn4PyMp0X4GYif6MqtWvXc58S5jqM2MtklwxCiN2l4iCva73DmUgs0eZj3rh42oHCsxDYwo4CwAzvMMCHcOG/1xzOQWb7YMl35lvME49SQCE5o1HL+AhHNvhUgbHFcmwaL0r436a0j2LyP+qrrqf1VwbZpmyL/By19/aKh+qOZSOgPDD5jv6xeMwtEGenkjaZ+pmGABtYeFFPuMepZq4WBgen2r7l8Wj4DpSK6fpIRWRU2c6gZQ77KlQ+TDXKQ0jNEowg1joYwlY4PKMqErgOYNfrvCgbZ8I+FANnW6+YItkTB9+eTm/NvwPmf+5BcK+EKpZr4eqvOiLsSNbhBT9TGRiCm1YLKPcJcbIlFQz6eNPynE3LlP2HP5kOaXiZXoBLPJ/wvE69RX/qlg1Lanul5S07tKK57lfa756k618gNgkdB2aivM7A0ApAVGkxEvLwdlINHkQ9Xk0eO5Vz3h9fD3UBbBYBsR6VvUDCGHAcrBUlZMznbQgg4KwtF4fh4CUdf0kk5RdbsA/9Qe0m4GqRcVSRXuyT/TuiQW3jcyBNZMZG0QU4g0JwAlmubEk54ANpaLYTyxDDNyUaSASYSkILbV22y8+Wg2pG7XXc6gfWRqTd8fAe0fBYrNvlPNiKA3+xHl/BrFizpXvevnTUuR+AXvCbGzwdXpXlSF9D62lx71bFUo0NmqEiGSThTwyMbpjAdiCCPuVR0xVQmyFtSzlS1AYp9Mui1t1uENIlUaoZZDjrfo/UiP3fEeoGzgdMVZrRNuBisMHXnmpeiY46GdEDoSFBqdfFGnPbwTr6gselEvi4VIUSjtjOQYH7arqJe/OBLqNbeFe6meZOJTKX2oXPdMfW6nwoObKLXZjr7GGF6pvHTfPo27rllCCRUsp9fs/jfhb5uP/ixNNcuPWsyBanBV/D8WbGIe+5VRYI1ik4ekDLl3WpAr4i9bREFECSEd9FdgGA7YP+aco3064KZOqN7/+Ub6vjXfHHFisnm5FBE2Ctt9J+93VdjerG8IU4IYcVR+K1qeEL92tXhhTizAYz6aLlLHOwn9dAsmQWb7SSEHgH5M6KgouxGUZiOwJkOX8qvhzZKnlc7xwPF7N7mgSYACbMjOxxO6ELY4MoBE8f2au2jm8n9Bl//qpFl48i5M3UvMKkj/9dYa43UypSsOPJeoARX10EgeDlc427rLWjDQEyScnw8pXCoz1YBzFAJUgazyBP8WkGQr1rLs9eAA8SzE8L0G5nV3bvVN6KLnAjt13ocTTPCcdxtGn8YTdzLETOqAszMGeWWbJSOJZ9rg/wzPHprJUxjcZVG7vES8iTFvUw2P9htkAEaIGuUvABhr2KdboRPcWWJQDtbOzt+jKUOljZXb/ruVOQXZwrxVgGR8NqPfIv4lhFwAsg0mOUjmojr6BBR75SGXGo9XOs1v3M9Bg2/poWVzilQ/3IIyszOex5epFHBzXJlswKD6TAAAKwSHiIMf9Na71eVdgvJSkb02krb9NCBm6T5WbjokWtfZFcMziiUDptQlK/TI/35gaJY03EPtnarff6AZBqQDdGImPEXxL+caP5DDTXRTdmnfX1X5wdPlp58MvGanMBWExkJUIWA43G5u/JNMF+tyF+oo6jssC8QdfaSHG2X/NkDxH8zTPFzftAkQ54dTihH19vsqvGxp2rGQntVIUT3+6nfjPrJ+WGo5LWM45GsIUvR9zpbNbbRi8H4a2vIc0EvvahQkqTpGRrxpUIqzcY7AFEEY5w+Rse0Ta1ztUn8NJIj+s3BVXzhn8Bczz+nM2lLx0m82f+S9kahHCHpdrIGS1ZOVRJzn0bpf+7Y/EwIgjtARxveuhhPbnEwmGBa2eQZnpUFJw7zGHC6aegpLPVFZB1eOtw9/E3LxpaXLOAoQi9OLAVPrIpREslEB2FGVPIfR9L4QO5e7mU9+E88z7rRZB/b3nokAU/3TVWsAPSgGv+rP2+bG77QvNyKlpx8vfbIxCDQ0NVHJJ72ldtohx6V8cnIqSNRfe/PuP2oKzpZfp+i05n/QOJ1xSgdseZSguWWz7DRnm5DeXi82dNeXUaHcpEuExs9z4sl4PK0UM93zsAczm5JqfUnJbmJO72WAMT546fcHZfrFcbEK9s3vWZ1+/y4XQP8YXFqoHppyEws+/YruE0ib9+PP1k2du2YEwbC4sphfd9B5O8JWh8aWa9Kd4ZSW0ml5zjiQW02xATLUdcOzm5qrX/s1H9mT0kJtCZH1+nt8A3s/qBTfWgJRUoVsii7cqIaBHs0TTCcBcqq8CYED7ryOMuxHvE3I5/L520+UiV3wDWEGlz+qHY5hh1DVdSbCKPG5yjoQN+TTTFpcJpIRxKzoL8TTFpt9F2KGVpRVmm+zrGKWJobJK4imgaaQxj89ygvekatMWlHinSSBdbNJfy/kpIfQ8dQyw0RB61HbZowKc7m5HXIewmuj+jqEyNm6Vulg2HYLOB+neJQ6HrelxnXZkjHjJwedp1lmM4pYG2arZ4JWuwsaChz9+as6/ygRup55xEzetY/hiiaLsXZ650bUEAujtVL8RZ2LNEzjUF4iZGffvxtaR052xnP3mvvnNXkdoBTJq3oOsPPb1eVU8fFOIoFNca7604dk1jtZBfSRUFs/TiA5cyLQ7GzBGznyIKNs6V6yZoC31DYOABjFy5XzVxuuvdz37bk45BmNCrufk+3UW6/zwgHoEOPWYFQncMGjkwwF3K12ii1nMYxPjMnyHYfnGdzIJxdhKCbmhcoze1UwYvNmlPYqBGBRvIxvmSOoYzRzfRr7bWHA/qhpCzdDH+zTX9LGIlJs/NcGQqtRVL9xGtx1yp1YnWM7U+YM8ZPVz9KTklN50nafrkJZq44gG+EAdOl+V7HQu3G57AuJmt8xb/LqiYJe6UV8tXIRSKxV2vEFyTlQUGeQsf42DKqLVHPbVCCYERrEi2hvF6417ibtIO0qcuxnEf1jFqj0mQGKN6OPwFiWgzuc+j0TcINgBQqER6cxALdYgLJAABIgnO4IXqZdXAespoktI0a9KCQXONeaVxGOhQQhPCf6ltUjwpekU8DjLD5Kg+WP1sY8rjOSCaZBLg41w3/dIjaVO6bz/F6sz3jrKESVqLj9jNj0dxFd7TRRYIusiTJb9nt6aTaougcfaFJfVS4i9zBzNQGz0mww8aPJHnMVDegCSWzDiGl/B4dkS0uwFsSNEu7B2ZnxhCV1kvH7X8UUPYgJa7jLjdTuE7kGk9H+bP8vL10vWTO3C0WxRFJNc4wHxfzuKo845TtfamBliDrXGsNz+o0FA1BGExNtM9v6n4sbtEUaBGarMVutmbiTKM2OUdxWaqCQlIYbfmynztKkxbFX4u43sxTijS2hZ4IqJOgAEIn5JkMCegz9BPB/wCaY2OhXV3iDKXWfn1KIXqKMkjN4BxaWM0m7T2hSd/gCivTW5CW9exsnzeqnLyIZu0N5qblMSnU6G+B+8Rkd7Ju1t574vsIILlbUo7JWV2DeJH7XyHuSVOmmUwG1baZq3NcAsQPFg0EsxX535TSeaZNNZeIgX8IU8RsZ+ZIE6ILcX1y4ybGOBUbr9+GeqcTtMoSK63Ig8/OB+AwZ8+ntKKScxUg43aMRxUelW8ad+8vK6slTXon/2NVc8o9ZQrsJl+BYXddtAmfkiJ5X1IkI4PvFXKgFx4Kbi9uOFkjqlKB1t6pC28VVUrZpe23lP9hWNucfUvypBXkfmY81Cd9gKe/6K6nFafVWMgTbSsw+kPdaVvObYofW7TGhVy+fgmS6quUGWuxlpBQNzFCAt19Mi7jFZwM89QX3xxm5U+FlsdISHXyW/DwvYJoHMY9UrPbm2HxCPBWQL9zt0N1DhlCWxy91zPWhuUljkduo1d9Cg1m4sq/A6WZtM4rmpg6FaUG3d1tmLVeD4u9VzTPG19vcuTFLugrh1NSi8xSkbtliiZcXivNVlChIJO/qHZoriA7EWm9TN5HufcV/naNCr39CFfwtce/TUvEOf1LmEwC2S66OZSsS5xZw7Up2wStG99i/cBz1+en9+WDwxIuMuZTyKIPGq8nXjaZndZI/yQdnKdC77Mq98iP0vybSBpKMtfNV2nBNjwBlLAi+/7cOABOpmrNfBREoBlIRSFvSZEF367OjoZE0lk1PJupfKqZDY4exviEGjLMxbmW66IiEep70O90eHpG833vTOuKw646tQ+KTMVCkcGM8tRqm8kqaXzhTIXsfdpusNvr5SyPvcl4pfVU2t69USpjIG4IRro+0q20Hhd1BrNnZtAivrJgc8jCDOhV4RuKioBS5yIbSM8B2lxUkUYnw2wBI6W10T0rz1ACBuTRXMFng6nl7M3lE5LaQtsgDjSGLryKBYMcVOBISCzsjSW9FFO96GAUWxlkligxnXk6MeH2NxiF1J+q4aQLov1ekj11Y2qu6RmUUgz70wKxFOuJtjpa9QTSUAmZ+/JJ/xQdT/vjXmU9lDkAJ9aSHXlKU/m1muKDmk4zNUG5c05s0ZapwonKlixrCMBQf7UI32xjvCTcVLvFBwzXFNeFCld8+B/9O1U1N5ZpCsz1dRae3PY+m6XYSSocklCVFuFlKXlhqbWqMq0zBt0GO7f1RiUP7RT8u4p4ItgtfSuaWfaiEUS6MM68Q3WIQDZNDdFG62qMSxI3w3fnD5csRChAEvjJ5BgZhBRSN9K41XHp3R9QLZPBr8gJ4g2lW849g9weVyg4beii4ii3NukjdcX0oaOFceYjtowz6kA6sHAPacwaVqzhH4xR3tuOMEkhLflqsdAnJ1GxQidajjnb7WLYsyftblGnaAHEP6h9d5g/MDGZgcd7+Sx2E2iRFxtDazBnVWWsD1bq+xaNqXgWl/D3woF7UZJ2zPX72oW6QDBWCeZLWTDlF50GTMe9zgNnuIe6dJFk33EUBTrLSgqK1Nn4FRee09KZpMHjTZDEfOK4Ck9GW4vsUVwFR+gCTskS4Mra7XGqmxwkw7F8RNR6B60n65Ai2UIKoBkuN+vK633+GM1/yUOXh2cHk093SlLYhZ+4fA7BS4OdHcK+Y8zYtSy7Souh+142TvA3ffUYclN6RPG2wwNkwlPI6Y/QTHJl21K5kff/Qkxt++IxxeAx0bgrm6XCLWkVbbq4MupnfX0uAjXnagOYXWAAAJISHkIMf3eyqd5t9K6fGq05XF4eO7AZJL7sfV6mZtw2qsZwRUvGIBxC+ktSPQwLXPbFzzix3CoGfHykCV5bW/9ICpdoe+NI9aV1hu5MIBjnm6GC4ufHRd91kdhjqPXxnHU3ByeonolOsyvOREvBXOtT2UsydQo4kbGdEkVcs5ZfhE8UGEnRspFC5rglDinIlpQ0RG40sbkE5p9NlajVYt+0Zba4iFKtHP05V4AlmcYOSh7E+qTtgmy72D9g/fd2tAiSs0lT565iTmqFovIaBvZSm+rQu0iQDiWalAlbycPBmbKf+9FVj2MAh50piWSp+IHTlo2dWiZ38FiqKWElimJ05TdRHcLdlHBq7/aX5OMg9I6I0lJggf4ThxMLKkNeHG3BN3ncLzZqYMTc4zqR8ZssYFOfXz1LRl1jfMLYZeu5JuRbnhQpez6CNrqxPbgxPv53iF71r35hU6QhVQAQefyMnTPxem7LmKHiihseAHJQ5Z/fW8FPzhbxhWHIYsFEb3hML3yjT/KqvwrDaxhcsUgEo4v8P2xgMVY8AE7JJclns7VVV6m7Iao+MSMEg3Zm3HRqybRYUDAv8+FF1xxCiaFYyDZXaKebR1DXDCukbftKBJCZpt96cr/peBLr5qUiU5amOIXmvYnA7DFarSjFXhfOghwm7KC2xciPwMuUw43RPaWZYlPBM9pPCoq9PLvMyg3Bch6MkYDW+itVc0CddZ/OxwYEUCMrHsgLv0HY5N9TXWNAIbfjrvCyQyMMYCsjLbE8cVVi+78Prs33mam2zuymz97TiCmHDgohr1zKYBO1bn0l2fixUNksxgJ213a09CO8JrScyX97E3O5p0DktjQoBmLqxzVtr2fL1yfDR9cdmHm8eCcyZEJ4x9TiM6LcYMkNEnGov4jkRMUkGhY/9c6rSseR1Ad3YDpw9g6dcDS9iwy6/RacXIuHdsXCgS86/frSdjEDvxjPCM9UhO56xtdiEYoSnC1lpS8AGx3C/pLWtZgxMR3S6dzaArGKKIyn1gksOIH+EyfSVQvSqHqS770mPXd274EmjyxAR1j2qHdyAvT8DONJaLnAr+r+JVN9nMTrY29Hqm1qQOg8DEQp3XVLkruobcoQPkrfVEjWROtrlmomlBSK/PCJEstoVOUpuyQ0a+VK35D0UpkI/M/p3fZHfxo/7sE9EfTh0VsYVWixVu34z37t7SetzLZiIV045CO0jGiazqA4L0ajZ+GmIQ6afgCH1+eD0McElW0uxC0FYIPSyJbgZVDAWSJGYoMiE6x4EYALCMuuMGwsIRwZYvGVl4PLXoXn3DbpwKzly8M3mjTLy6nAKK6sKmpbwi5iYUMCptnPUTKQF+GxYJs7XBqo+tk6Q5MLBxwPPZiG++6KHjwXoeoHAnEseRMrgxwCiAGeeCy5S7tC2km0ii9muc+CpfimOKWQ5kgSkIcDKZVkSINNCPxTO9/2Hr0/nwUxTc+dMWhhZ+51Xb20gn7MCHEVKQSYMesx1E41b1zlzDsUfYoGTo8fcllafcvw9hts2MKWH/thFhpDK8FhM46SRYcpzBBlwgtqUmo0LcmwRmgxj0x0TBp08aetxCyDMueAKuXVi0ItRJn7BQwUsCYG6c13QaKNa5PXSeDuVw2Uv0Dn+Bsj82DvFa/XpR1U0olD1BB0irhoe77zpk3QWY+BoiYzc49c2xLZhH4f9H9buBCTHfWxZ1iHJl0W8O/CdTXiZzfsSTupgNxCGLI2CXoFYgrYD4bDZ8IOXgLH7h6q1PcgvgSFbS/mtpOM3OX+1Yyuvg0848eATHb+rz5FKftGIeO+BnO45LHv/Rsk0LS69iEsLJje+DxCLufKP9SkE1c1WYCzgxBynPPxpghVH/o9D6W2jBz1UMWcNeRfzUT9SGYlrLr99jOHS8VdRNi3mR/J17EwKNXjIKSKuKwxH9qcL0OtDm9GGe7AjyHMyPSoTFil2dXp6rK0M9z6RaHk4PUxXOF73q+O1MmXY8jHnLw06hd1wOTMbXBg0pDumtyrsO2AK+xUfq2Q9rVDd4Gh/VNC424ijpild9arh0BUyQOR0GwrO22IDibmw60A2nU5j2tVsu4vA86tdHfJhzKNXaji9l+tQXmbkWABBtOaYy+n+/dj1sh7+8Br0OaNtBnLD3yGBLAhHkFaIbh09OVH/jMNPA+KYnD/s5vCvSYoSLTimU3f1Ln62fqkyP2+MWKQqkVmD7eem5usfn38Pnl7dr3DLbtXv78lv1U0zJ3aCfFMJ0zHgZ1T2RDct4QIZ9GAKPIQomIpz6pgRqjBswI5jHWEPdY1ffK3RyPKgEHTJUXjRWzoP/cOhJmEdHT5TG1vqcQDo9OjRnNHvujpbyEe72p/a9Jwc8prHvxnV8fPWzMYIA6lvaYFhMET7KK7D30/pIBBgePcrflX7MvRP/7g4F8sGIrP8iq+QGfoe3o7KMeGaXOR046W64yACEt8IsbKYve+8gT86UB30ApP1XS4vhi8KXlf/QAUQBeDrEvVqeTM+aaYwzZHgs5u6pQMK6cwi8VOJMxQjZuu/EBhn6zbEtUdW0UeP5faS3Z3nLuINhVn9r5OmhkYseRCx8JwkEbDLxh3O3XfkECJwgiOdfC79Mn3H1mMXz2cyPQDUbsSXHnz3K5YRfjIkND9WisuiqtRywa6KW99vJamXLMxbi0VCKVC6a4YpqiL41RcM6Qr9b3gs7e9INm/lFGfUE8NMOE7d/a/cGe9o+o53+7k2t437IdLmWMzlZOlRgAgQnDr1RAtiwGVgsu8N0/ElFZac1Zc/19JwVXNjSs+zEuuKVE/e42oWyZX1xDxzwoOV7Ln9yfMt41XbyRt95SjlytA2O40XhwmUnyjOhevFdrHvc19PQJLeQJZUJfv8ugMab4wHFyVi1Ql939gBa6uFvpijWiFeOtRpUrMY8mwkv6ffCqmhXq4UOXrA8tTejKAiDQr8s929VADPoGraWfu4Cn9FULuanp+0Btlizy09qQUYNMsoy5tsnkslTM/8kLSovtMBTSv/OdfmZ17WquHtnSvxvO2ABx76ovyzE+US3ujT7DtVWxJBTbxiE0ULgiL85LglcVs4YcriwVrIIrCioGEONMnOlVWZ62AAAB4wh5iDH93q+vedIl3AfumSuL/XiJnaLP3tkasjXxhxJTgeGY2PE19+7EAja0py1CZA+V7sVGktLsRc2181i0ptZN0FpFNbIZFnUbs4DdINsmrTSWtzjZ1pi0xGkYSxBHNlUS3TvRz9ZimdG+fl2M6Yz0QQHZkg9L32zXQiIEHuEBh1j2m2TFUE8XaKW8l0jIZTqLIxVGBgxzBNYpPokdT+oOjLHM1n8Ly/XaVIv6zhtlnGsVBfDG4bQdBY0oOFmh86n07avTR/FUT81ivnvCRBtwmFk1Vrn4mNDwjkrlUAyZrq0ysKQeVuSSMvZZkCmyc54vIBqm2ZwHqgLzc7ZKxmBOseiQRXV/A1blMkjIfmHwxrtvdkOQcBHl2T6p+KAbzy3VHmWYRj6LlD72PILorluGAMrIp4U4p9gTRynJvU8lJdzeeXmzs9k5ogUD21sK8DrDDj4ivIe8qnCJgU6DKCcwZqsnOBB86K5PSWjhP1ODm2Xy70NbxWNMYZFF2stch+KwcC1IxH8GB3RWFMqiHV6hTIZSo7VJWKWmH3e9Lr0D2c6Xec21rsCzhgSamNHHga+O/WM9wNYL5jYpqL47WLv5D5SgOvd/O/RZ9g10GdOQkci5YQoEk+JEFzLrNX6STBq+WIVDeCCkssM22xAUg6okadV4cQcj7UxF6L+1HfL6PZ2lvLHJZW8How6BclbCAeOEXQIodxPoV3+/F8i/6JzgHkCuQk1ZufEk5zJdi0xHXm2XaKNQ4hVaCMqQEi4GNkTREjk+8tI+eShjIffKNFvmzDkauzRFOLhO5a7SS0f5F9i+Df4/1tTt5H6V963E+8qD/c2ey4KughmrtE7RkMCP3z4W32VTJPSoteXrRT1ewq4a/gl3bXy8mHA0J1ZWotvGjSVY+GGDYieybHDN03CNdBdO+gzOnuiVr/f2nDLe41B1zewebDMg+yb6zTBVD+TjN3R69oTFclzvoE4Kr317Gj1XHdBgwvZus/htbGQz0YFQhXN781L6D90p3KmANCcee+TQ3EitJDcjDjz88Qvfkv8w+2iWgmgIlEktDZvpBlCRDGSi70Mz7lZg01J1bBpjMtp7PIE/lQoYBySv7XyyYAyUpuMcSm3JY7MUsbB71r+vFgvPzJ3bSUCQ1OOn886jDRh81vvVgvF1+wJeXV1Ts9jJTAfufv874KMag/KNEtJrTi4fkhUeIU94IG8f2SQz/BvkNC4pUiiRu2lZ0//DqEZ5v8+jiYMi3B8f6kKlYqLANEekBLmIWolpx0TIl4+3WAId/dbOdFQiW5OsHoZwJT6x2+68KCQ6rxCETQZqrbfKTMy8k99yFsgf/ZXFYp0gdjuw9hwmXjojL9ijG2rcFwnuIeKpe0tplJlxfxBtlTKW8oshu++cBqMNjj9Qne+8gzxRg2E7hZVLR6drzbJEGehK7cGdmJ7i/pNc2ctipAL+Bx2WEKyZJwEimfEwm46tjt4J9td0V/zfNWD0sgCDoCNdO1BncVJmod+ZVyAy5v2pZvAmPvPe6ipt4E2XIzH41jLq/Onan83Ld6QlxQxS/LQUgWaOwYpTFjv59HmoE53vjwcoj+I0QFfNJ+/zoWYuycyorDJIU/yam1rOunmxQzBC9Z/IPn0os9vpY65h0JyTA2tnLcQMG91IrXB3Fv4cGDtOF9DQ4iFyoyXdhNhBYIfXMyViiZqS7GRGMfa8JSLr5dij5DkmVxCzF93LLs11lFn4GegVUSyRDeAtUaSmLmswjzheoyQAP5ciKIAFztqVmWco8ZkoG/5/gKiF8gahIlnXC5t10CMTw8opWZ7YhTUqcTczEfCB0T1/3lIwYcXOUNwz5b4BUF1EvFnPCYBbHVcHnhY8QIZzKANdbA1U5KStFaQfk3F+lBNcZNgwxUeS+XJAxS3J/HLBzGx7DMl5kBvom4MhqAjP8GuByzyILRIYi6SY7v8QDBOGxyLDeVS6zbp9xvAbx3RoeZgYl94/o504Hnuoc+ldoKCJmZZ3QITBoKJdSFizYooWYrZfFo8oa+qie8WfZs/K6dl7UtrlWzhclShuQ5P3nBfnd6tbHhzg7YC7B83VEoDn+TiqarhTBz64Z6bRYNuGmoMf2jaqhtyqCf+F6DEuhWkw5S1YzR6bsxotYy6JqZw2+IGMCQ6hDeRTkux6cvL+PiLt46lwWKOtSTflpMlZawy9bFFwLOynsqHyUYYJI8YLx/ANKs0RU12B6APvM+8GI1bAmJbT1o/Ut2C22Ljvis509VLB6YbAXKO4j6GqY4GhXrOsfX/YbBOxo8UphaNcUSPE/n0kUAUgujQxxkgoBLkLLrD/4UXLjryZCN/dMVgLyPV6XcXSX9mAOAra0G0VPBn1qigDAfmj2u2yKl+yJZh7hKFDatCv/HFP8KjtgrNenWaF3H6RZ/rUJAXoVICupEjw8tX8m9AYSgbjM42lgWK5f+gyyhQfw5kipW9Qgtxxv3mPAriVUGb1dJ3n2WHPASMXc/m7e/zLMyeCso3QVy756t+3xyeapBQ1Cf9jz4OTsf/eGQfQncOpYx+rr/j2vitiVAYrs5Qb3Zgm0m3lrAAAAk2Ieggx/efjFsXalovcCjpB9eGqz38qQtpXGK2aYnK6Qfwr/6/65Wg9nfHZVFSh542nN7goNn4/IsPpbGX9rJuOz1CZt6h1f/3m041D1LWIUZS/NdHOqfmI3VAwr6o9qc40mZHObKMDy8ByLkveZSheToQ3DggPi00nQSbX0FSa1fsbXMRsET8s/QY50XFDXuBvJpgticKsB1miF/DsUt8Vj4adcWRb1pBrnxP5N7ubfIY2obksPvoaCfL2srMWd3bIE+8+V2kHXZcQQHjJGcpJ8zxk5lX24WY+UznGo9pnB7VveU2HeCNM2r+Jfzo/NUOmGOknsK5/9FPZ/HbXeYiuanx+TqUc8f7OabEKLKMx1wJjKw5bNjD+6YLxPHqrD268tkyfuaGEwQmruk+l+0t3aQ2Y1e+lz94cC8HD4bN6pbN6SPhRy4QKmiWJIxxwPSn9WZ04Qg4jKO354OXjlF7W5dRds4fYkJsvDzUv7J9nJtRqOplTzq2y5JybotZpeSaA8+5UE+8ZFELAMSzDIpM7JzSaFpnP7DAqJmIh8SskxDF/FfLyZO32qZWoKdA6djhxT1duN+ATLhUKY2Z595siYs90N37JatwE23KD1qYGwgRvoC/I7AG41HX013ffwz379zqszn5aI8MRgCgRFCmKBdds2VNNTfFGaXKbh0LD4oCXAdFTIobM3szNm9p7saYZ9hik5xaa/X4yBcDEcQxu0Tv4fiY4mw0CY5+R8nVjcvnYJeOX40EwW7WM7NwxT7/Ojd3v+H2bX5OSlgyXmVoKHSVaZXY+gEEugQ2pu53hDvxIeyqJ4xtUcfwc0bMYwQlPVX2dBWp+YLu8JYo/p+wkmfVWhqa5BxNx/ey2KrnBit5LSx4l1JcKeitLAI7piH/2AsrzviHhVWuqF8uXu63SA+cLkVgGuFLS0oOJjv/OK7f/q5IMZng4fVkdJ2KBBSy2OiLXMkK1Ig+RKnGsDnHSpk7CFsxNCC3bU9ePGhCOBv53biKeCqcyMBCwbeFwC8taK1bimRnKRFj/IM9EC1Uykb37O2mVPBFY09bmTL5w6jUkLdtdLVXC5pcO5o+UZrDn6RXRltxylPVv/4FBpw6l2mqcbrUuqma117bY/FQKb8TQf7xc+eBDWxQoasF/ArQjI9oeUSqKi/1gajq/lRpmHi1MnHmlZjwn+nfHL80kRjElkra8cjigKqur89G39PR8X0FMc+BquYGw1I7fNcqIXmvaupjtF6buI5ZIAWwFmrlKEQ9Vu8L0Sle9PxK9gqcia6/DDq+4yQQnW7OcpIMUcmdHea6T2UGjMojT9rPnYXSDQEDlN6wcZuNKY8pzOZqarwkJXK0ql52s0xqdOVxJBivtRasO7m5aXEYuwWF3vnrBv+LDHm2/4XH7P1CRUN/IR6GqX0X+2RNP+M+MXtiw4nkyje2bqvdUUpKZUr8AslGLZNl4hPoZgS5X2462Yp3gRbiu9krId9ui6LwTekg1EtgRKrbH+59tl03oKNsMcwHiZG9QhwjzhqGajaSvjejp3RX/WiFWXxkfJnY34NXJHXh5EBVVg0dLfLkU8khBcwOgINmx82o1fqMR/lOBENlGLjwO2G4IL6TuU8V/qxitzO4PmiXKCLE+lCeH8qS1VPjwF198IW3szlEypOdRFzji+uGEPMzNLqh+dJ0yltd1LikM33irCZyWOuFBoFOLJ4D3YKH28+PB7HEqOd07t7YLzqTbvqviTB+bSTru9g3gtTzoehLQbkjnHNmzKgE5T9ljuSuHX29HbRviR4ig9CAFmRyI6idIshVX8Ng9LCKRWyIHANWDmcsmNA7vV3+UIDc4r3oAvpcK1el+1Ll3pIg4q5OZycNmEKlGKNnFHoK7WuV2Nxtpi8fBCUfxk6DIYzb6q3Xv7mkYHhhZvjgDAvn/2rF9Bc28u2x8Vdi17ItxFGjQyxChHlKPEY7BnBJN9g9Ssv3zHkG8KztrewF/lBJH5E7dTXxMZGJypFguQSwXKncIjyZRubo8qKFCW8h8G35BYx+L/dUIAci9FF7BNME7YrYoi5AFS5P6jAj7Ipul/xrPAHNuUo1SUe7+GxePiwzudn98c/ExjDwici9BqpS4coz0pbQpWmYhlTBgCxlPKLNbBcNeFNBmhR/2O84e7dHkd51UQdWoQg5kk6KrcMygarDkJAlkX0Uw7wHlpYRDxjcWMegwrfMa/RO22CxG7FYeLhH3H9X2vxEJTWWHoV+9UefnQZ9cvFMWCJ5dr7bgUDfBQsJtXiScyI0iUnHjZYrQsfLqSKiuLtTBWM9WgCQFOOtnMOINVFm4c4ODHgfprTjCaqfbtOojtBk8jqeAL4eo6qDJvHKiCYx3wxZzs33A6m62zzEMy8ikzRSQmnfqXJrk1Qbr3h5ge5C1bnQtA3IB+kQXsjOVY10B+G6K/m6ylSXOVkwAvGDaaPaTu7oSLxkUjzlA/mcj2MMIy6YjhdB7e1iDBknVx55FlsKJsl2Y4k1J3MiP8sRV2rCmIzvqWmVDHoEfCXbil2mt2SmWmdIKeL+QSf/cO83bYcGtyHd2/so02Vj3onQLMXCr93AjoF4vHwSn6/XH30apeV0BXabudP4vBNcUbTM25lJbkU/y3tYNHGkSEdGwTeDbH/5/ofLR2TRWeLfnuuf2bCTu58XhTH6NMjmHg534ix874aNrJfzKXlEgriTc7sJ4uWbxyQYhY2baGyzC8/GKGDQ1wLnpGCxU+e+5cw26tqZobG4wWGxEsAjm75uYKH6cngpAy2osalyN+EAdM8Xp1ENDXG8TBkNbucQQDYMpTkYfl17uroiCNGVFzYoqkB9/+BFtDwANYQqW+1FyZYpHR3NtBSu55vF+9agRm9YEnTI1LZWWpB06p0OMZGigAq2uwJZCa6+k7QUd3F9Ql4X4AYuWSKVO88EpsYzMJx9eEWnkBFo9BK/T29ZOd2rZ5wRrv4wdeNwPhIPVWJJoy6p6TpChwm/80QCPktuJ3e358lYG52X/zOaotvYkGnJRpPJMIbe7yuAScTft7uYKgfSeMWQtloug7eEyshh1/eX9G4mbHiG2jvNL5LhVX8kwgoFH6bkThZg+G9bnKWzbq9k1rL2QFscSnHrnqd9rKKs+nYGGMo4I4toijA4AAAEwCHqIMfwlmjFcqyt6ebemjD9ysBtH2lnAX+ZKQSuNMob59tXS3Cz/rn7y9kESf6Br16qQCJPIti3E3WRsTlaYDMcQxUddJ3wKnFfq6GFZfGDtTl4M/aVtnVapd5SdI92wRtldPNi0DB/C70/fNAD7sHXNaq2rzGm0Z7GuauXD+tbZOTjt7t0mclqdsm8KmS29rUFtAaHWMq5/GoFyNYZPMdw/1WnLzuciSm7zesyYlTyULj2c5Fh2JVMoAfEpHmbfYSCobPko4dyWTa7K3UqoKTauDcvi6LrqORUbrssaJ/J7dOJrYMW9Ul5PZqS/rQ3XOinEJ9g7yr1/f97dNFFZClhVAoeP7J940FvKYZ2sPmFfYZrlPnfE5IZgchMFDTJN3wRpI6d0a8xq3i4X87fMaamwADe5HIUwcy3TOrIdVTB3ZrjmzsL41z2UnE+8xxSyWqUQzQI1Ryw9cepJuvq5ktbDwbNnjmMS5jwYNjkjBTSUREzIyrBifMIsSj2H4OVYl6CNZdTv4QfTJyK0K76/qzuyu3qPQALPaYL5Na+cneWs1FcfKJgRIDhycGCHZBbwgef1OPtAFGSMebBnlTKDZ3sgQL30MlXyoLv3Ce2rCodQt25WtS4RfSLrDAxq/XWFNiAn9Vr8qcxZbYsIHxn68S+gdyiZicWWIj0xFDaXTmav9ze1peyLvIUbPgJTymo9XuHfY0DcZJCvTX2RerD54nvDKbIWGvdn4xBS5rMXewrs/sY21nQJkxZNOXQdlMFK6yWQzYwaFwrLTiYb+JWRctaiWgmhYWGxM3YjoHPksLU4B2rpvNwhVUBDwZdtFiPL8Jg3G2yoPZH1z4EixQ1xDmbfFiGZRw6uxI9dtg+7OZ3RVxAry5pDjsMh4dIIHiJaK3wHClu1MsPlNT5jCzXayfzFaGYrHoxUFgJCC9wSqcYj8+kG4y0KzEDNplzoQxVBJNTA5f806fJSx/iHe4aQ0FySr7cqKnvAoUagerJKfxgxiwCb6P5U78twIkAU7sSh11eTYjy1vVjfERDP080irfrLFShVoA8slYYricyHjF12p58kvlq+Zh6/JubymuWC5Yh58jEUvfo3Aaivel6WaofG8J5D/qFYn3Uf3i9VQC2diF/95eJTNolKbu0ilZ0lyE6LG/HFRzXGMzuyWqCGYJ9BC0AD63CXVp3ca5yIanN709BZ/IAF6Q6mq/kByAu/QYeEy72Kb3+mb8FZdqhRPEuusG5BBXDaX4v8uFp2tCC5rIhtPCtHajN8Wr1WK2w4tuIPjW18GILHH8SoN+i6O1T7YFWSdIQXQpbKOy3ygTPu7wf7B5JIYPJ4pcPNwcRiGTKRLhi+nbAztp4P/NPl1XKa1Oe2w1JxvmiV5mNRUA25SSLdY/WbCV9dd4IjPh8pEJBcvD7fG4RAHNhq+W4WzKe0gfOr22JtCCNyhkcmeZwTktwel9hlXoAz2cxwOeFwOBfENEqEAiYjZgrd7xgLq/1V3lxEew9O67EcF8Fl9yuI/zYtwAiScTk/Dd3naQmBD3h7O8skRYhg3VKCpjwIYKxOTWe7doxqwdFTFLT0HLaJSy1yLoxW6jacf5AF/Lhrk5R6jSddkmZv7MQPjx+1p4AAAbNIewgx/CcqgLXpmmIxEqkzbDjlEzf2e2xO9NURs6Pz1apdSlkhy6Qy/T/ywzZOw7O3ybDyUY2rwZQ2URTFnhvV2GmkrNOacfHrNntzGYCABQs8mrE7CeOPC6pJ6jxOPkRGer11un9M7zFfOoBF/XoPUXus2Eosui2QSgkZtEoOSDH6Wnp8cubxPSuLYpId+TpRNTMQ1uuo1wu756IZ0YLayNoFW653V9QpKHUkXHIqDaj9K9hb/ZGTUAHH/dbETbes+UhMZeKbmERMnE2QeWyl/H9kMxVUkmqb4GoFciO8iplC6Q9ugbTTw2gAFCM4cef431nBx+d0Eb5uaaUb/0fIYxbtmCRlHffBFj0DemvafOsPRO5Puzx92iLt1pHyDz4TpwROcOxHAwbqWE2p/M2qXcswR7mmqGhilGo2jwXtgX7mI0xPRK05UABFjsX8KBUiR8dOJbIXwgZk1ZN8vm+pqA+wQxoiVgbrSQoXYR38cX/A8MGzGbY+5rlZISWj3GDvD32Q+3V732rUQYSUcXbpZ4BJGtQslccJZs5yE2c2cjRbcq1Tjb43idsZ1g7fGMZJ+P1ZNG6h4aE/H1ssEd/OG1fy2gvnFE+LqkEQnVoNF5KMjyEg4vFBLU5TfeFWB3RHARrNSOpDUMewjmNPlUyiybWSXZwrVmeiS8dXcnLCjQJD1ScDPcbtbK94QXp+LqycTF3JusM9E+MqrwbWvXsuVdJ9wX8DxfqZuF0s8Uo1jBvBXD91K4RwkVt+3Wwx1yQcxbbM8FMeCvrcYPQyIX2V5lH/4YGoCe8hpn5CnCTrQilHJL4Ndg+eRVLu0IW7F+tNE9wbC2XxaTNl+dcHbh5B/eFRlDO4ZftS1VIqmjr6X0reTORJkwHrMMEBFSR/OhSAyyg+BkGuSga/Z6F0ARUUG4/y3vYUD7JrlPwAfAQDN9xWqd4RCbgXwh6Fw5lluKd++HOPaUNtD3thy61PeRnMpIDRNaqhhLeS+HZYeIqWL3mY58DsREYOiVhOK3OTQH0cF75QlRP0/LI2cW42UhF7pZ9MuC9VXiOj4l9w/PHgH/6rVz17RW11DsXLa66+jxM64+Lq+75eI3jgD8U37vSTewXhYvhE8d+4rv8EUrC4iOtSZKElkTnh8J/FMwQv9/nVIK+k1VtzSudsoDOTSxmy16QkTP3c02httbMeJ3LZ8TdSGOm3MbBOrrGqq/8A0STiMD9OWALt0WBr/imbT2jtjqG+xKehfFdhHMa7y2F6LZb+eiLtlgyj64nyjTWKcb7OAh5yfvgzlxQAzcZPtQU3HGe7LLfLF7TjTI44zvy/mjXDcnQcW649Uc9+6Gzms9kU/zBKluPAt++HtHtF1v1bUT2haQaYV6Er9WKLzVSRaFPhk8Y6+4kip/uVVeRb3l+3ejcJMqocAopliq+YZs+BVps/NpbldXhb7mhN/Cd0Nyf48/icx8IVD95vYRmlSeUQN1tU1QH9L7pax/J7lETf/WwKLssRQ/wfmgUkcX+J2t5O8iPc45AgLkWofUlhHQPK3+/eY53S0XT0LAoaw1MCdirM5VzavGFgmvD0Fh2EwMwD9SR/X0vHpbildwj3KsjS3XgqW2nOOLb3nSr0oZarrn1f69r2kInuDuuvG0S0Io/aFnWWV0yZTf5EysC3tJDf/pxUFyjMOOjdmTQXzvoJT6ghVq8hm7IYavXtj+nEavFNH3YYb7bQyaR/TXwlXTJSsyAMr744lCpfjuO3++nzJrZjuSrRo47+AlUjHkxjMiIdo5xuyyjkDRaNqqpuerRJ39vRqvTcaHPmI30coFcXRmYjWJBj3rTFhM6RcRzrZIIbLuGWH6Yak2aMyZYMDwutyviWlSdF8buheVyDCQX/eIjuLMq2OvRTdoJxwP+jN0D7zmIv1BLqcJ45DL3CyGZWo/l5vbudnWr1ZQZSgqBVrUp2JACDFRJlMoo6E2NDsKGgjMPmngaKV9Ob0iXfHoduEE0vzN3BJyyhxNsxh8VBXIAJzFNWlkE2S+faWhrOKb2i4wkaOlG0Q3wV7R00OROW+H//DKPjIli7gzVmy8hXE7LomAskuPpCP4IbNnWDQEZgZZOufd6QtEmtqB+lN1OtoSA/9swVrjm3QGBtM/SMrywNoPgXbg2PptniJp8uODsf846CjsJc9cjlnf4W75e2pOneUDBc0Dt6n/eVzLXBbMVUNJk+grgcU6xle+roqRsMmA6pQF4aqwaCRDeZNChwEuyP4j3gKaK.';   
  document.body.appendChild(video);
  const playVideo = () => video.play().catch(err=>console.log(err));
  document.addEventListener("click", playVideo, { once:true });
  document.addEventListener("touchstart", playVideo, { once:true });
}

document.addEventListener("visibilitychange", () => { if (wakeLock && document.visibilityState==="visible") requestWakeLock(); });
document.addEventListener("DOMContentLoaded", () => {
  document.addEventListener("click", requestWakeLock, { once:true });
  document.addEventListener("touchstart", requestWakeLock, { once:true });
});
</script>

</body>
</html>